# ChatGPT Plugin Upload Compatibility Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Produce a ChatGPT/Codex ZIP that meets the documented Skills-only package requirements and stays synchronized with AIPM capabilities.

**Architecture:** Keep canonical Skill source bytes unchanged. The ChatGPT profile generates host-only YAML metadata in staged `SKILL.md` files, plus portable and Codex manifests with required listing metadata. Archive validation proves the host projection and source inventory together.

**Tech Stack:** Python standard library, JSON, ZIP, SHA-256, Python `unittest`.

## Global Constraints

- The registry remains the protected source of truth.
- Generated host metadata must not modify canonical Skills.
- ChatGPT package metadata must use only documented, non-secret values.
- Rebuild and validate ChatGPT, Claude, and Antigavity archives after any Skill or Prompt change.

### Task 1: Add ChatGPT Upload Contract Tests

- [x] Add a test for portable schema, required identity/listing metadata, and YAML front matter in every bundled Skill.
- [x] Run it against the current builder and confirm it fails.

### Task 2: Generate And Validate The ChatGPT Projection

- [x] Add profile metadata and host-specific manifest/Skill projection logic.
- [x] Make archive validation distinguish source files from generated host metadata.
- [x] Re-run the new test and full Plugin distribution tests.

### Task 3: Synchronize Policy And Release Metadata

- [x] Add the Automatic Plugin Synchronization rule to `AGENTS.md`.
- [x] Increment the platform and TUI patch version, refresh the protected registry by confirmed CLI workflow, rebuild every distribution, and record results.
- [x] Run the complete repository test suite and artifact validation.
