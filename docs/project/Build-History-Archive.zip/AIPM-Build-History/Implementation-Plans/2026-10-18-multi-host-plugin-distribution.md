# Multi-Host Plugin Distribution Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build verified ChatGPT/Codex, Claude, and Antigavity capability Plugin ZIP archives from the approved AIPM Skills and Prompts.

**Architecture:** The existing capability registry remains the sole catalog authority. A new, isolated build subsystem reads that catalog, copies the approved source material to a temporary staging directory, validates a host-specific package contract, and writes only verified ZIP files and SHA-256 sidecars below `Plugins/Dist/`. The legacy Project Agent Bridge remains unchanged except for documentation that identifies it as a compatibility package.

**Tech Stack:** Python standard library, PowerShell, JSON, ZIP, SHA-256, Python `unittest`.

**Spec:** `docs/project/Architecture/Plugin-Distribution-Architecture.md`

## Global Constraints

- Work only inside this repository.
- Use `Capability-Library/Registry.json` and its provenance ledger as protected source baselines; do not edit them by hand.
- Include 12 approved General Skills, their owned Prompts, and the approved standalone Prompt inventory; exclude Personal Skills, `import-memory`, and `morning`.
- Use the AI Project Manager Personal Use License in every generated archive.
- Keep host access permission-gated and fail-closed; an archive never asserts host installation or local Core access.
- Preserve independent Skill versions and the legacy Agent Bridge version unless their own contents change.
- Do not publish, install, or attach generated output to a release.

## Review Focus

- A forged or stale registry must fail before staging or writing any archive.
- A source symlink, sensitive-looking file, or excluded capability must prevent artifact creation.
- The standalone Prompt must be present exactly once in every profile and remain distinct from Skill-owned Prompts.
- A ZIP modified after generation or paired with the wrong checksum must fail validation.
- The Antigavity profile must remain explicitly `FORMAT_UNVERIFIED`, never be presented as provider-runtime-tested.

---

### Task 1: Define Host Profiles And Build Contracts

**Files:**
- Create: `Plugins/Build-System/profiles/chatgpt.json`
- Create: `Plugins/Build-System/profiles/claude.json`
- Create: `Plugins/Build-System/profiles/antigavity.json`
- Create: `Plugins/Build-System/README.md`

**Interfaces:**
- Consumes: the architecture specification and platform version from `Capability-Library/Registry.json`.
- Produces: immutable profile documents with archive prefix, manifests, host status, and expected layout rules.

- [x] **Step 1: Write failing profile-contract tests**

Assert the three known profiles expose exact IDs, archive prefixes, required manifest paths, and `FORMAT_UNVERIFIED` only for Antigavity.

- [x] **Step 2: Run the profile tests to verify they fail**

Run: `python -m unittest Tests.test_plugin_distribution.PluginDistributionTests.test_profile_contracts -v`

Expected: FAIL because the profile files and builder contract do not exist.

- [x] **Step 3: Create the three profile JSON files and build-system reference**

Define `chatgpt`, `claude`, and `antigavity`; each profile declares only the package format and runtime status, never local-file access or installation state.

- [x] **Step 4: Run the profile tests to verify they pass**

Run: `python -m unittest Tests.test_plugin_distribution.PluginDistributionTests.test_profile_contracts -v`

Expected: PASS.

### Task 2: Implement Deterministic Multi-Host Package Builder

**Files:**
- Create: `Plugins/Build-System/build_plugins.py`
- Create: `Plugins/Build-System/Build-AIPM-Plugin.ps1`
- Modify: `.gitignore`

**Interfaces:**
- Consumes: `Registry.json`, provenance ledger, `profiles/<platform>.json`, `VERSION`, and root `LICENSE`.
- Produces: `build_archives(root: Path, platforms: Iterable[str], output: Path) -> list[dict[str, Any]]` and platform ZIP/sidecar pairs.

- [x] **Step 1: Write failing archive-inventory tests**

Assert each profile archive contains 12 `skills/<slug>/` trees with registry hashes, `prompts/Autonomous-Task-Execution.md`, `AIPM-Capability-Index.json`, `AIPM-Distribution-Manifest.json`, the profile manifest, license, and no excluded paths.

- [x] **Step 2: Run the archive-inventory tests to verify they fail**

Run: `python -m unittest Tests.test_plugin_distribution.PluginDistributionTests.test_builds_all_profiles_with_full_inventory -v`

Expected: FAIL because `build_archives` does not exist.

- [x] **Step 3: Implement staging, copy, manifest generation, atomic ZIP output, and sidecar hashing**

Use `tempfile.TemporaryDirectory` below the repository’s `.test-workspace`; stage every archive fully before atomically replacing its output. Preserve source bytes for each Skill and standalone Prompt. Add `Plugins/Dist/` to `.gitignore`.

- [x] **Step 4: Add the public PowerShell wrapper**

Expose `-Platform ChatGPT|Claude|Antigavity|All` and `-OutputPath`; call only the repository-owned Python builder, return non-zero on a failure, and print artifact paths plus checksums.

- [x] **Step 5: Run the archive-inventory tests to verify they pass**

Run: `python -m unittest Tests.test_plugin_distribution.PluginDistributionTests.test_builds_all_profiles_with_full_inventory -v`

Expected: PASS.

### Task 3: Implement Archive Validation And Failure Gates

**Files:**
- Create: `Plugins/Build-System/validate_plugin_archive.py`
- Modify: `Plugins/Build-System/build_plugins.py`
- Modify: `Tests/test_plugin_distribution.py`

**Interfaces:**
- Consumes: an archive path, matching `.sha256` sidecar, and approved current catalog.
- Produces: `validate_archive(root: Path, archive: Path, profile: str) -> dict[str, Any]` that returns `PASS` or raises a build error.

- [x] **Step 1: Write failing tamper and policy-gate tests**

Assert validation rejects a modified ZIP, wrong checksum, added Personal Skill path, omitted standalone Prompt, unknown profile, stale registry, and Antigavity host-status escalation.

- [x] **Step 2: Run failure-gate tests to verify they fail**

Run: `python -m unittest Tests.test_plugin_distribution.PluginDistributionTests.test_archive_tampering_and_policy_gates_fail_closed -v`

Expected: FAIL because validation is not implemented.

- [x] **Step 3: Implement validation against the current catalog and profile contract**

Verify ZIP inventory and content hashes without extracting archives outside the repository. Reject unknown or unexpected contents and validate the sidecar format `<sha256>  <filename>`.

- [x] **Step 4: Run failure-gate tests to verify they pass**

Run: `python -m unittest Tests.test_plugin_distribution.PluginDistributionTests.test_archive_tampering_and_policy_gates_fail_closed -v`

Expected: PASS.

### Task 4: Document Operator Workflow And Compatibility Boundaries

**Files:**
- Modify: `Plugins/README.md`
- Create: `Plugins/Build-System/Quick-Start.md`
- Modify: `docs/project/Architecture/Plugin-Distribution-Architecture.md`

**Interfaces:**
- Consumes: final PowerShell command and profile status metadata.
- Produces: short command-first operator guidance and explicit installation/runtime limitations.

- [x] **Step 1: Write a documentation-link and command-contract test**

Assert the Plugins README names the platform command, points to Quick Start, identifies the Agent Bridge as legacy compatibility, and does not assert host installation or local project access.

- [x] **Step 2: Implement concise operator documentation**

Document one-command examples for each profile and `All`, explain how ZIP and checksum files are used, and state that ChatGPT/Codex installation depends on the account/workspace import or marketplace workflow.

- [x] **Step 3: Run the documentation contract test**

Run: `python -m unittest Tests.test_plugin_distribution.PluginDistributionTests.test_operator_documentation_is_actionable_and_safe -v`

Expected: PASS.

### Task 5: Execute End-To-End Verification

**Files:**
- Modify: `CHANGELOG.md`
- Create: `docs/project/Phase-Reports/Plugin-Distribution-Report.md`

**Interfaces:**
- Consumes: the new builder and tests.
- Produces: verified local artifacts and an honest report of generated, but not installed or published, archives.

- [x] **Step 1: Add the platform changelog entry**

Describe the multi-host Plugin builder and clarify the host-runtime boundary without incrementing unrelated Skill or legacy bridge versions.

- [x] **Step 2: Generate all local plugin archives**

Run: `powershell -ExecutionPolicy Bypass -File Plugins/Build-System/Build-AIPM-Plugin.ps1 -Platform All`

Expected: three ZIP archives and three checksum sidecars under `Plugins/Dist/`.

- [x] **Step 3: Validate all three generated archives**

Run the validator once for ChatGPT, Claude, and Antigavity; each must return `PASS` while preserving Antigavity `FORMAT_UNVERIFIED`.

- [x] **Step 4: Run the focused and existing capability test suites**

Run: `python -m unittest Tests.test_plugin_distribution Tests.test_p06_capability_library -v`

Expected: PASS.

- [x] **Step 5: Run whitespace and generated-output checks**

Run: `git diff --check`

Expected: exit code 0. Confirm `Plugins/Dist/` is ignored and no archive is published or installed.
