# Project Organization, Plugin Homepage, And Release Implementation Plan

> **For agentic workers:** Implement inline in this session. The owner explicitly requested completion, local/GitHub synchronization, and a publish-ready release. Steps use checkbox syntax for traceability.

**Goal:** Archive project-construction records, document the current AIPM architecture, expose the canonical project URL in supported Plugin metadata, and publish a verified SemVer patch with local and GitHub source synchronized.

**Architecture:** Keep operational source, user guides, provenance, support status, and release notes in their current product locations. Move only historical construction plans, phase reports, checkpoints, and handoffs into one transfer ZIP; summarize the current architecture in `docs/project/Architecture/Plugin-Distribution-Architecture.md`. Treat Plugin manifests as generated output: update canonical generators, tests, then rebuild and validate all profiles.

**Tech Stack:** Python 3.10+ standard library, PowerShell 5.1/7, `unittest`, Git, GitHub CLI/API when available.

**Spec:** User request in the conversation; repository rules in `AGENTS.md`.

## Global Constraints

- Keep all filesystem work inside the AIPM repository; do not touch the Universal AI ToolKit source.
- Preserve Skill masters and protected capability records; refresh protected baselines only through the confirmed CLI workflow.
- Keep the generated multi-host Plugin outputs based on the current registry and target-specific manifest formats.
- Keep platform and TUI SemVer equal; independently bump the legacy Bridge only when its generated metadata changes.
- Do not claim host installation, CI, or cross-agent validation unless actually performed.
- Do not force-push; preserve all pre-existing local work and synchronize it to the requested GitHub repository.

## Files And Responsibilities

- `docs/project/Architecture/Plugin-Distribution-Architecture.md`: authoritative overview of the platform, capability flow, build/release commands, boundaries, and current directory map.
- `docs/project/Build-History-Archive.zip`: transfer archive of internal plans, reports, checkpoints, handoffs, and design specs.
- `Plugins/Build-System/build_plugins.py`: generated multi-host metadata and archive README.
- `Core-Engine/aipm_core/capabilities.py`: generated legacy Bridge metadata.
- `Tests/test_plugin_distribution.py`, `Tests/test_p06_capability_library.py`, `Tests/test_p10_release.py`: plugin metadata, generation, and release allowlist regressions.
- Root/TUI `VERSION`, changelogs, versioned release notes, `Index.md`, `README.md`, `docs/README.md`, `docs/project/Support-Matrix.md`: synchronized documentation and release status.
- `Capability-Library/Registry.json` and provenance: refresh through the explicit CLI only after version/changelog updates.
- `Releases/`: deterministic source ZIP and SHA-256 sidecar.

## Review Focus

- Historical files must be preserved in the archive before their live copies are removed; test the exact archive inventory and checksum.
- No live documentation links may point to archived/removed reports; verify repository Markdown links and search results.
- Plugin website metadata must use the ChatGPT listing field (`interface.websiteURL`) and a stable repository URL; verify every generated archive.
- Product/TUI/legacy Plugin version records must remain consistent and SemVer-valid; run the full test suite and release verifier.
- Remote synchronization must compare remote main before push, then verify remote commit, tag, release assets, and checksums; never force-push.

---

### Task 1: Consolidate Historical Build Records

**Files:**
- Modify: `docs/project/Architecture/Plugin-Distribution-Architecture.md`
- Modify: `docs/README.md`, `Index.md`, `README.md`, `docs/project/Support-Matrix.md`
- Create: `docs/project/Build-History-Archive.zip`
- Remove from live tree after archiving: `docs/project/Plans/`, `Phase-Reports/`, `Checkpoints/`, `Handoffs/`, phase implementation plans, and historical `docs/superpowers/plans/` and `specs/`.

- [ ] Write the current architecture map from the implementation and active docs.
- [ ] Package every identified construction record and verify names/count/hash.
- [ ] Remove only source documents proven present in the archive; preserve guides, provenance, rules, support matrix, and release notes.
- [ ] Update indexes and all links so no live page points at the removed records.

### Task 2: Add Project Website To Plugin Outputs

**Files:**
- Modify: `Plugins/Build-System/build_plugins.py`
- Modify: `Core-Engine/aipm_core/capabilities.py`
- Test: `Tests/test_plugin_distribution.py`, `Tests/test_p06_capability_library.py`

- [ ] Add failing assertions for the exact project `websiteURL`/homepage fields and generated README link.
- [ ] Run the focused tests to observe the expected failure.
- [ ] Implement supported metadata in canonical generators only.
- [ ] Regenerate the compatibility Bridge with the official local CLI and build all multi-host archives.
- [ ] Verify host manifest contents, inventory, and SHA-256.

### Task 3: Prepare And Verify The SemVer Patch

**Files:**
- Modify: `VERSION`, `TUI/AI-Project-Manager/VERSION`, root/TUI changelogs, current release notes, release index, README, support matrix, registry baseline.
- Create: `docs/project/Release-Notes-v1.0.6.md`, `Releases/AI-Project-Manager-v1.0.6.zip`, checksum sidecar.

- [ ] Advance platform and TUI together from 1.0.5 to 1.0.6; independently advance the Bridge metadata version when generated content changes.
- [ ] Add release notes and synchronize all current/latest-release links and status.
- [ ] Refresh the protected registry using explicit confirmation and a reason.
- [ ] Run full tests, generate/verify all Plugin archives and source release archive.

### Task 4: Synchronize GitHub

**Files:** all requested local changes in the repository.

- [ ] Fetch and compare `origin/main`; preserve unrelated remote work without force operations.
- [ ] Commit the complete verified local tree and push to the requested repository.
- [ ] Create/verify the matching `v1.0.6` GitHub Release with exactly the local ZIP and checksum sidecar when the authenticated environment supports it.
- [ ] Compare local `HEAD`, remote `main`, remote tag, release assets, and SHA-256 values.

**Completion command:** `python -m unittest discover -s Tests -p 'test_*.py'`
